`1.0.7`
-------

- FIX: reapply lost changes from version `1.0.5`

`1.0.6`
-------

- **Fix:** The compatibility with website_sale_delivery


`1.0.5`
-------

- FIX: Redirection error on the address page

`1.0.4`
-------

- FIX: Errors for languages different from English

`1.0.3`
-------

- FIX: Compatibility with website_sale_suggest_create_account, website_sale_require_login, website_event_sale

`1.0.2`
-------

- FIX: fields depend on a type of delivery/payment

`1.0.1`
-------

- FIX: fixed issues for v10

`1.0.0`
-------

- init version
