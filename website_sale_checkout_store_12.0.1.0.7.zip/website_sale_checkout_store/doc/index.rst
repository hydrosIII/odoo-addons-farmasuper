=========================
 Pickup and pay at store
=========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

* Set sale ways:
    * Using administrator user go to ``Website Admin``.
    * Mark the required ``Ways of sale`` in ``Shipping and billing`` section.


Usage
=====

When user enters in shopping cart he will see several purchase buttons, according to marked ways of sale.
